package frontend.symbol;

public class FuncSymbol {
}
