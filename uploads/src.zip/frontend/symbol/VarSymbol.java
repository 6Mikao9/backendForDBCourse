package frontend.symbol;

public class VarSymbol {
}
