package frontend.symbol;

public interface Symbol {
}
