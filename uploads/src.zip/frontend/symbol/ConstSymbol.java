package frontend.symbol;

public class ConstSymbol {
}
